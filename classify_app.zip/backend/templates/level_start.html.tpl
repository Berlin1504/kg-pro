<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>شهادة بداية المستوى</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&family=Amiri:ital,wght@0,400;0,700;1,400&display=swap');
        
        body {
            font-family: 'Cairo', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e2e8f0;
            margin: 0;
            padding: 2rem;
            display: flex; flex-direction: column; align-items: center;
        }
        .certificate-wrapper {
            background-color: white;
            width: 210mm; /* A4 size */
            min-height: 297mm; /* Full A4 */
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            position: relative;
        }
        .certificate {
            border: 2px solid #0f172a;
            padding: 40px;
            min-height: calc(100% - 84px); /* Changed to min-height */
            position: relative;
            background: linear-gradient(to bottom, #ffffff, #f8fafc);
            display: flex;
            flex-direction: column;
        }
        .certificate::before {
            content: '';
            position: absolute;
            top: 5px; left: 5px; right: 5px; bottom: 5px;
            border: 1px solid #64748b;
            pointer-events: none;
        }
        .header {
            margin-bottom: 50px;
            text-align: center;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 20px;
            position: relative;
        }
        .header h1 {
            color: #0f172a;
            font-family: 'Amiri', serif;
            font-size: 3rem;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .header h2 {
            color: #475569;
            font-size: 1.5rem;
            font-weight: 400;
            margin: 0;
        }
        .body-text {
            font-size: 1.3rem;
            line-height: 2;
            margin: 20px 0;
            color: #334155;
            text-align: justify;
            text-align-last: center;
        }
        .highlight {
            font-weight: 700;
            color: #0f172a;
            background: #f1f5f9;
            padding: 0 5px;
            border-radius: 4px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin: 20px 0; /* Reduced margin to save space */
            background: #f8fafc;
            border: 1px solid #cbd5e1;
            padding: 30px;
            border-radius: 12px;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);
        }
        .info-item {
            font-size: 1.2rem;
            border-bottom: 1px dashed #cbd5e1;
            padding-bottom: 10px;
        }
        .info-item strong {
            color: #64748b;
            font-weight: 600;
            display: inline-block;
            width: 160px; /* Increased to prevent wrapping */
        }
        .footer {
            margin-top: auto; /* Pushes footer to the bottom using flexbox */
            padding-top: 30px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            font-size: 1.1rem;
            color: #64748b;
        }
        .signature {
            border-top: 1px solid #0f172a;
            padding-top: 10px;
            width: 250px;
            text-align: center;
            color: #0f172a;
            font-weight: bold;
        }
        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-30deg);
            font-size: 8rem;
            color: rgba(0,0,0,0.02);
            font-weight: 800;
            white-space: nowrap;
            pointer-events: none;
            user-select: none;
            z-index: 0;
        }
        @media print {
            body { background: white; padding: 0; }
            .certificate-wrapper { box-shadow: none; padding: 0; width: 100%; height: 100%; min-height: 0; }
            .certificate { border-color: #000; height: calc(100vh - 84px); }
            .certificate::before { border-color: #333; }
            .highlight { color: #000; background: none; }
            .info-grid { border-color: #000; background: none; box-shadow: none; }
            button { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="certificate-wrapper">
        <div class="certificate">
            <div class="watermark">{{ institution_name }}</div>
            <div class="header">
                <h1>شهادة تسجيل والتحاق</h1>
                <h2>{{ institution_name }}</h2>
            </div>
            
            <div class="body-text" style="position: relative; z-index: 1;">
                تشهد إدارة المؤسسة بأن الطالب/ة الموضحة بياناته أدناه، قد تم تسجيله بنجاح للعام الدراسي الحالي.
            </div>
            
            <div class="info-grid" style="position: relative; z-index: 1;">
                <div class="info-item"><strong>اسم الطفل:</strong> <span class="highlight">{{student_name}}</span></div>
                <div class="info-item"><strong>تاريخ الالتحاق:</strong> <span class="highlight">{{enroll_date}}</span></div>
                <div class="info-item"><strong>تاريخ الميلاد:</strong> <span class="highlight">{{dob}}</span></div>
                <div class="info-item"><strong>العنوان:</strong> <span class="highlight">{{address}}</span></div>
                <div class="info-item"><strong>رقم هاتف الوالد:</strong> <span class="highlight">{{father_phone}}</span></div>
                <div class="info-item"><strong>رقم هاتف الوالدة:</strong> <span class="highlight">{{mother_phone}}</span></div>
                <div class="info-item"><strong>المستوى عند الالتحاق:</strong> <span class="highlight">{{level_name}}</span></div>
                <div class="info-item"><strong>السن عند الالتحاق:</strong> <span class="highlight">{{age_at_enrollment}} سنة</span></div>
            </div>

            <div class="body-text" style="position: relative; z-index: 1;">
                تم قيده في الفصل: <span class="highlight">{{class_name}}</span><br>
                متمنين له دوام التوفيق والنجاح.
            </div>
            
            <div class="footer">
                <div style="text-align: right; line-height: 1.5;">
                    <span style="display:inline-block; width: 100px;">تاريخ الإصدار:</span> <strong>{{date}}</strong><br>
                    <span style="display:inline-block; width: 100px;">رقم الشهادة:</span> <strong style="font-family: monospace;">{{certificate_id}}</strong>
                </div>
                <div class="signature">
                    توقيع الإدارة المعتمد
                </div>
            </div>
        </div>
    </div>
    <div style="text-align: center; margin-top: 20px; width: 100%; display: flex; flex-direction: column; align-items: center; gap: 10px;" class="no-print">
        <button onclick="window.print()" style="padding: 10px 20px; background-color: #0f172a; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 1.1rem; font-family: 'Cairo', sans-serif;">طباعة الشهادة</button>
        <button onclick="downloadAsImage()" style="padding: 10px 20px; background-color: #059669; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 1.1rem; font-family: 'Cairo', sans-serif;">تنزيل الشهادة</button>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" defer></script>
    <script>
        function downloadAsImage() {
            const btn = event.target;
            const originalText = btn.innerText;
            btn.innerText = 'جاري التحضير...';
            btn.disabled = true;
            
            html2canvas(document.querySelector('.certificate-wrapper'), {scale: 1.5, useCORS: false, logging: false, backgroundColor: "#ffffff"}).then(canvas => {
                let link = document.createElement('a');
                link.download = 'document.png';
                link.href = canvas.toDataURL('image/png');
                link.click();
                btn.innerText = originalText;
                btn.disabled = false;
            }).catch(err => {
                alert('حدث خطأ أثناء تنزيل الصورة: ' + err.message);
                btn.innerText = originalText;
                btn.disabled = false;
            });
        }
    </script>
</body>
</html>
